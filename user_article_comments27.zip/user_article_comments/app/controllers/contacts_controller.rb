class ContactsController < ApplicationController
def index
render :action => "index"
end
def new


end
end
