# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
UserArticleComments::Application.config.secret_token = '4a27d4d84932d43d23765dfad00f9907d84dc656e84a7f278c7aedb9c496af767e9c408ef4dd116e4ea3a935d38ca9d1e7ea9719d31db465afd508bb234231f6'
