# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Heroku::Application.config.secret_token = '11e493db3da2ad51968231366efc38ec64b91feb42aa447500ad336b6149a711b4fedbfecd3db33dbdc57fb4cbb097b70096b80f40da8cdbcfa4718ac0b8b492'
