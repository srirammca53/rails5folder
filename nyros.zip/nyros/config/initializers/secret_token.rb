# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Nyros::Application.config.secret_token = '622bb7695226204c67970e9d1c3fb814d5c09f781fa6f1e7c48c59b82a1cd55e63fdf531c9e1559214fb944f3bd2d100a468fa78b5992b5e009bc2bfe50c94c2'
