class Employee < ActiveRecord::Base
has_many :registers
end
