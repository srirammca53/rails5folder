# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
OtoRelation::Application.config.secret_token = 'f7149f06b827ba87972efd37bca88f9f6d4776df167ccc0ebee060a7a2e5764cb82933bbb4c871b50b0e61d0150cc831244935b7f6848600ff8c6d51dc1fab6c'
