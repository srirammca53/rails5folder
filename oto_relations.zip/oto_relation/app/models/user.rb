class User < ActiveRecord::Base
has_many :articles ,:dependent => :destroy#:uniq => true
has_one :profile , :dependent => :destroy
validates_presence_of :name
validates_presence_of :email
end
